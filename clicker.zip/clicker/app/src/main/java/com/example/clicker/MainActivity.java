package com.example.clicker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final String PREFS = "clicker_prefs";
    private static final String KEY_COUNT = "count";

    private SharedPreferences prefs;
    private TextView counterView;
    private long count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        count = prefs.getLong(KEY_COUNT, 0L);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(24), dp(48), dp(24), dp(32));

        // Счётчик
        counterView = new TextView(this);
        counterView.setTextSize(64);
        counterView.setTypeface(Typeface.DEFAULT_BOLD);
        counterView.setTextColor(Color.parseColor("#212121"));
        counterView.setGravity(Gravity.CENTER);
        root.addView(counterView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Пространство между счётчиком и кнопкой
        View spacerTop = new View(this);
        root.addView(spacerTop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Большая красная кнопка
        Button bigButton = new Button(this);
        bigButton.setText("НАЖМИ");
        bigButton.setTextColor(Color.WHITE);
        bigButton.setTextSize(28);
        bigButton.setTypeface(Typeface.DEFAULT_BOLD);
        bigButton.setAllCaps(false);
        bigButton.setBackground(makeRoundButton());
        bigButton.setStateListAnimator(null);
        int size = dp(260);
        LinearLayout.LayoutParams bigParams = new LinearLayout.LayoutParams(size, size);
        bigParams.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(bigButton, bigParams);
        bigButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                saveAndShow();
            }
        });

        View spacerBottom = new View(this);
        root.addView(spacerBottom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Кнопка сброса
        Button resetButton = new Button(this);
        resetButton.setText("Сбросить нажатия");
        resetButton.setTextSize(16);
        resetButton.setAllCaps(false);
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        root.addView(resetButton, resetParams);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmReset();
            }
        });

        setContentView(root);
        showCount();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle("Сбросить счётчик?")
                .setMessage("Текущее значение: " + count)
                .setPositiveButton("Сбросить", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        count = 0L;
                        saveAndShow();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void saveAndShow() {
        prefs.edit().putLong(KEY_COUNT, count).apply();
        showCount();
    }

    private void showCount() {
        counterView.setText(String.valueOf(count));
    }

    private StateListDrawable makeRoundButton() {
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.OVAL);
        normal.setColor(Color.parseColor("#E53935"));

        GradientDrawable pressed = new GradientDrawable();
        pressed.setShape(GradientDrawable.OVAL);
        pressed.setColor(Color.parseColor("#B71C1C"));

        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed);
        states.addState(new int[]{}, normal);
        return states;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
